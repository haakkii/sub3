#include "Dept.h"
#include <iostream>
using namespace std;

int main() {
    Dept com(10);
    com.read();  
    int n = countPass(com); 
    cout << "60�� �̻��� " << n << "��";
    return 0;
}
