#ifndef DEPT_H
#define DEPT_H

#include <iostream>
using namespace std;

class Dept 
{
    int size; 
    int* scores; 
public:
    Dept(int size); 
    Dept(Dept& dept); 
    ~Dept(); 
    int getSize() { return size; }
    void read(); 
    bool isOver60(int index); 
};

int countPass(Dept dept); 

#endif 